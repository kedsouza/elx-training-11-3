from flask import Flask
import os
app = Flask(__name__)

@app.route("/")
def hello():
    port=os.environ.get('PORT')
    message ="Hello World from Flask with PORT %s!" %port
    return message

if __name__ == '__main__':
    app.run()